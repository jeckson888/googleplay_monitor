mkdir -p /opt/googleplay_monitor && cd /opt/googleplay_monitor

chmod +x playcheck
./playcheck

# 5. 设置每周二、五 21:30 自动运行（crontab）
crontab -e

# 在打开的编辑器里粘贴下面这一行（vim 按 i 进入编辑，粘贴完按 Esc → :wq 保存）
30 21 * * 2,5 /opt/googleplay_monitor/playcheck >> /opt/googleplay_monitor/check.log 2>&1

# 6. 检查定时任务是否生效
crontab -l

# 7. 查看运行日志
tail -f /opt/googleplay_monitor/check.log